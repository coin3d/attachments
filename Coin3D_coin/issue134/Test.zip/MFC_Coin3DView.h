
// MFC_Coin3DView.h : interface of the CMFC_Coin3DView class
//

#pragma once


class CMFC_Coin3DView : public CView
{
public:
	SoWinExaminerViewer * m_pViewer;

protected: // create from serialization only
	CMFC_Coin3DView();
	DECLARE_DYNCREATE(CMFC_Coin3DView)

// Attributes
public:
	CMFC_Coin3DDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~CMFC_Coin3DView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFC_Coin3DView.cpp
inline CMFC_Coin3DDoc* CMFC_Coin3DView::GetDocument() const
   { return reinterpret_cast<CMFC_Coin3DDoc*>(m_pDocument); }
#endif

