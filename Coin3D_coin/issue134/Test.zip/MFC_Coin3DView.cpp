
// MFC_Coin3DView.cpp : implementation of the CMFC_Coin3DView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "MFC_Coin3D.h"
#endif

#include "MFC_Coin3DDoc.h"
#include "MFC_Coin3DView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFC_Coin3DView

IMPLEMENT_DYNCREATE(CMFC_Coin3DView, CView)

BEGIN_MESSAGE_MAP(CMFC_Coin3DView, CView)
END_MESSAGE_MAP()

// CMFC_Coin3DView construction/destruction

CMFC_Coin3DView::CMFC_Coin3DView()
{
	m_pViewer = NULL;
}

CMFC_Coin3DView::~CMFC_Coin3DView()
{
	if (m_pViewer != NULL)
		delete m_pViewer;
}

BOOL CMFC_Coin3DView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CMFC_Coin3DView drawing

void CMFC_Coin3DView::OnDraw(CDC* /*pDC*/)
{
	CMFC_Coin3DDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (m_pViewer == NULL)
	{
		m_pViewer = new SoWinExaminerViewer(m_hWnd, "Dom", TRUE, SoWinFullViewer::BUILD_DECORATION, SoWinViewer::EDITOR);
		m_pViewer->setDecoration(TRUE);

		SoSeparator *root = new SoSeparator; // remove me later
		root->addChild(new SoCone);          // remove me later
		m_pViewer->setSceneGraph(root);         // remove me later
	}
}


// CMFC_Coin3DView diagnostics

#ifdef _DEBUG
void CMFC_Coin3DView::AssertValid() const
{
	CView::AssertValid();
}

void CMFC_Coin3DView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFC_Coin3DDoc* CMFC_Coin3DView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFC_Coin3DDoc)));
	return (CMFC_Coin3DDoc*)m_pDocument;
}
#endif //_DEBUG


// CMFC_Coin3DView message handlers
